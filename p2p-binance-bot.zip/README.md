# P2P Binance Bot

This is a placeholder README for the bot.